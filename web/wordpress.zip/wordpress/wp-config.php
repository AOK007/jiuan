<?php
/**
 * WordPress基础配置文件。
 *
 * 这个文件被安装程序用于自动生成wp-config.php配置文件，
 * 您可以不使用网站，您需要手动复制这个文件，
 * 并重命名为“wp-config.php”，然后填入相关信息。
 *
 * 本文件包含以下配置选项：
 *
 * * MySQL设置
 * * 密钥
 * * 数据库表名前缀
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/zh-cn:%E7%BC%96%E8%BE%91_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL 设置 - 具体信息来自您正在使用的主机 ** //
/** WordPress数据库的名称 */
define( 'DB_NAME', 'wordpress' );

/** MySQL数据库用户名 */
define( 'DB_USER', 'ccc01' );

/** MySQL数据库密码 */
define( 'DB_PASSWORD', 'Qq2389110614' );

/** MySQL主机 */
define( 'DB_HOST', '192.168.1.11' );

/** 创建数据表时默认的文字编码 */
define( 'DB_CHARSET', 'utf8mb4' );

/** 数据库整理类型。如不确定请勿更改 */
define( 'DB_COLLATE', '' );

/**#@+
 * 身份认证密钥与盐。
 *
 * 修改为任意独一无二的字串！
 * 或者直接访问{@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org密钥生成服务}
 * 任何修改都会导致所有cookies失效，所有用户将必须重新登录。
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'oT$.,zK]E+Y`yc=LbaJ4_8sA@jxUj!<uDd~I Qew}&Y yPox+R?ttVjhkaBb9yD[' );
define( 'SECURE_AUTH_KEY',  '}V^bol =#G;bAKy]|[ VZbccb}|S.`7xYkZ!y:)SFeQhMwXu.CL`kW;o!aEe3z{K' );
define( 'LOGGED_IN_KEY',    'im9OAps2_eo(.,?pB2;qm#>8~+rR6C#8wJ4:PUIbn^#K}Cqi6F~+zAAy&)$wAO1?' );
define( 'NONCE_KEY',        'AA622]z)P?|c~?Kx;6X6y`,zI2>_$,M=nZ?gJwu6v^$P(>]qbHWJK!0<%x% ;}ab' );
define( 'AUTH_SALT',        'HE.0n>MiPIN<ut|lail?2)]=t+Xb6>N?{>x;AybwDJYZ[ S}qeKw {ja_cpcj2gW' );
define( 'SECURE_AUTH_SALT', 'j8MsBFa0U{I<5;[4Z}Ui6gMErpl)@WCa6T0l!!XgZ~_<_ZhZ5S[nb8cHl)kd4RUA' );
define( 'LOGGED_IN_SALT',   ' G4?vst[=01vn4VUABKeu=An).]+P1)%`U7[r20`&{n;;Jr(f$!2~>fSsJAijxOy' );
define( 'NONCE_SALT',       'aoD-$X{yX{N<Zoj,@LayymU*shf)cbdv4:JyB`nD=Aig63A>gF&FVQ1{ {f0j4N;' );

/**#@-*/

/**
 * WordPress数据表前缀。
 *
 * 如果您有在同一数据库内安装多个WordPress的需求，请为每个WordPress设置
 * 不同的数据表前缀。前缀名只能为数字、字母加下划线。
 */
$table_prefix = 'wp_';

/**
 * 开发者专用：WordPress调试模式。
 *
 * 将这个值改为true，WordPress将显示所有用于开发的提示。
 * 强烈建议插件开发者在开发环境中启用WP_DEBUG。
 *
 * 要获取其他能用于调试的信息，请访问Codex。
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* 好了！请不要再继续编辑。请保存本文件。使用愉快！ */

/** WordPress目录的绝对路径。 */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** 设置WordPress变量和包含文件。 */
require_once( ABSPATH . 'wp-settings.php' );
