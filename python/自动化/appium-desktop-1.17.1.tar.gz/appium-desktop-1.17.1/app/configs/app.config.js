const config = {
  platform: process.platform,
  languages: ['en', 'de', 'ru', 'ja', 'zh-CN', 'ko', 'hi', 'kn', 'ml-IN', 'pa-IN', 'te', 'pt-BR'],
  namespace: 'translation',
};

export default config;
