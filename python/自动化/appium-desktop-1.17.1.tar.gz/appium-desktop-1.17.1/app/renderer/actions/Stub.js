export const NAME_OF_ACTION_1 = 'NAME_OF_ACTION_1';
export const NAME_OF_ACTION_2 = 'NAME_OF_ACTION_2';

export function someAction () {
  return async (/*dispatch, getState*/) => {

  };
}