module.exports = {
  timeout: 1, // 10 minute timeout for E2E
};